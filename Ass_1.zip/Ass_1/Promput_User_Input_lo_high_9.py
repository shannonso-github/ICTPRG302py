# File Name: Promput_User_Input_lo_high_9.py
def get_valid_number(prompt_word, low, high):
    #user_input = -1
    while True:        
        user_input = int(input("Enter "+ prompt_word  + " between " + str(low) + " and " + str(high) +": "))
        if low <= user_input <= high:
            print("Data entered is: " + str(user_input))
            return user_input
        else:
            print("Error: "+ "Enter " + prompt_word  + " between " + str(low) + " and " + str(high) +": ")
    #return int(user_input)

prompt_word = "Column position no"
get_valid_number(prompt_word, 0, 2)
input("Press any key to continue...")