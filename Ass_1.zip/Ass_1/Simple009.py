#File name: Simple_009.py
i=0 # row
j=0 # columns
c_array = [[1,2,3],
    [4,5,6],
    [7,8,9],
    [10,11,12]
]
print("Array length is: " + str(len(c_array)))    # row    = 4 i
print("Array length is: " + str(len(c_array[0]))) # column = 3 j
# str(c_array(i][j])) # i = row j = columns
print("c_array[3][2] " + str(c_array[3][2])) # should print 12 i = row, j = column

for i in range(len(c_array)):           # row
    for j in range(len(c_array[0])):    # column
        print(c_array[i][j])

input("Press any key to continue...")
#c_array = i0[[ j1, j2, j3],
#    i1 [4,5,6],
#    i2 [7,8,9],
#    i3 [10,11,12]
#]