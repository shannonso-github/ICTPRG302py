# Fiel name: function_menu.py
def menu():
    print("DOS-Style Menu:")
    print("1. Option 1")
    print("2. Option 2")
    print("3. Option 3")
    print("4. Exit")

def option1():
    print("You selected Option 1.")
    # Add your Option 1 logic here

def option2():
    print("You selected Option 2.")
    # Add your Option 2 logic here

def option3():
    print("You selected Option 3.")
    # Add your Option 3 logic here

# Main program
while True:
    menu()
    choice = input("Enter the number of your choice: ")

    if choice == '1':
        option1()
    elif choice == '2':
        option2()
    elif choice == '3':
        option3()
    elif choice == '4':
        print("Exiting the program. Goodbye!")
        break
    else:
        print("Invalid choice. Please enter a valid option.")
