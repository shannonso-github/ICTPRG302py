
# File Name: Simple014.py
# Example of different data types in python. 

# Integer
num1 = 10
# Float
num2 = 3.14
# String
name = "John Doe"
# Boolean
is_valid = True
# List
numbers = [1, 2, 3, 4, 5]
# Tuple
coordinates = (10, 20)
# Dictionary
person = {"name": "Alice", "age": 30, "city": "New York"}
# Set
unique_numbers = {1, 2, 3, 4, 5}
# NoneType
empty_value = None
# Printing the values and their types
print("Integer:", num1, type(num1))
print("Float:", num2, type(num2))
print("String:", name, type(name))
print("Boolean:", is_valid, type(is_valid))
print("List:", numbers, type(numbers))
print("Tuple:", coordinates, type(coordinates))
print("Dictionary:", person, type(person))
print("Set:", unique_numbers, type(unique_numbers))
print("NoneType:", empty_value, type(empty_value))
