# File Name: Simple016.py
#
# Append  some data to a text file in python
def append_to_file(data, filename):
    try:
        with open(filename, 'a') as file:  # Use 'a' mode for append
            file.write(data)
        print("Data has been appended to", filename)
    except Exception as e:
        print("Error:", e)

# Example data
data = "\nThis is additional data that will be appended to the file."

# Example filename
filename = "output.txt"

# Append data to file
append_to_file(data, filename)
