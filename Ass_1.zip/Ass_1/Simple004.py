# File Name: Simple004.py
print(__file__)
input("Press and key to continue..")