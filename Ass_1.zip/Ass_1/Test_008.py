# File name: Test_008.py
# Provided data set c_array
#         0   1   2
# row 0 [-2, -2, -2],
# reo 1 [ 1,  1,  1],
# row 2 [-2, -2, -2],
# row 3 [ 1,  1,  1],

c_array = [
    [-2, -2, -2],
    [1, 1, 1],
    [-2, -2, -2],
    [1,1,1],
    [-2, -2, -2],
    [-1, -1, -1],
    [-2, -2, -2]
]

# Check if the specified positions have the value -1 in c_array
positions_to_check = [(0, 1), (1, 1), (2, 1)]

for position in positions_to_check:
    row, col = position
    if c_array[row][col] == 1:
        print(f"Position {position} has the value " + str(c_array[col][row]))
    else:
        print(f"Position {position} does not have the value " + str(c_array[col][row]))
