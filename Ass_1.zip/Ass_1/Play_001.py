# File Name# Play_001.py
columns = 7
c_array = [columns]
c_array = []
c_array = [None for _ in range(columns)]

numbers = [
    [1, 3, 5],
    [6, 7, 8]
]

for i in range(len(numbers)):        # row
    for j in range(len(numbers[i])): # column
        print(numbers[i][j])

global a_array

rows = 7
columns = 3

c_array = [[-1 for _ in range(columns)] for _ in range(rows)] # reinitialize array

for i in range(len(c_array)):           # row
#    print("i = " + str(i))
    for j in range(len(c_array[0])):    # column
        # if num % 2 != 0:
        if i % 2 == 0:
            c_array[i][j] = -2          # [row][colum]

input("Press any key to Continue... ")