# File name: Test_008.6.py
# Desc: extracts the values from the specified 
#    positions in a row and checks if all three 
#    values are equal to 1. If they are, it prints 
#    that the row contains all three 1's; otherwise, 
#    it prints that the row does not contain all three 1's.

# Provided data set c_array
c_array = [
    [-2, -2, -2],
    [1, 1, 1],
    [-2, -2, -2],
    [-1, -1, -1],
    [-2, -2, -2],
    [-1, -1, -1],
    [-2, -2, -2]
]

# Combined set of positions to check for each row
positions_to_check = [
    [(1, 0), (1, 1), (1, 2)],
    [(2, 0), (2, 1), (2, 2)]
]
global row
global col
# Function to check if a row contains all three 1's
def check_row_for_ones(row_positions):
    row_values = [c_array[row][col] for _, col in row_positions]
    if all(value == 1 for value in row_values):
        print(f"The row {row_positions[0][0]} contains all three 1's.")
    else:
        print(f"The row {row_positions[0][0]} does not contain all three 1's.")

# Check for each row's set of positions
for row_positions in positions_to_check:
    check_row_for_ones(row_positions)
