#file name: extract_u_re_002.py
import re

# Given string
a_line = "9 12/3/2023 [1, 2, 3, 11, 14] [19]"

# Define the regular expression pattern
pattern = r'(\d+)\s+(\d+/\d+/\d+)\s+(\[[^\]]+\])\s+(\[[^\]]+\])'

# Use the findall() function to extract matching parts
matches = re.findall(pattern, a_line)
data_stream = []
data_stream.clear()
# Extract and process each part
if matches:
    for match in matches:
        for part in match:
            # Remove '/' and ',' characters
            part = part.replace('/', ' ').replace(',', ' ')
            # Split the string by spaces to obtain individual values
            values = part.split()
            data_stream.append(values)
            # Print the values
            print("Values:", values)
else:
    print("No matches found.")

print("Final data: " + str(data_stream))
input("Press any key to continue...")