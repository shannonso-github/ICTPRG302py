# Function to read data from a file and store it into a 2D array
def read_data_from_file(file_path):
    try:
        with open(file_path, 'r') as file:
            # Read lines from the file
            lines = file.readlines()

            # Initialize a 2D array
            data_array = []

            # Process each line and split into numbers
            for line in lines:
                # Split the line into individual numbers
                numbers = [int(num) for num in line.split()]

                # Append the list of numbers to the 2D array
                data_array.append(numbers)

            return data_array
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return None

input("Prossing read data example: .. .. ..")
# Example usage
file_path = "your_file.txt"  # Replace with the actual file path
result = read_data_from_file(file_path)

if result is not None:
    print("2D Array:")
    for row in result:
        print(row)
