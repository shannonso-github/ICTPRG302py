# File Name: Simple017.py
# create an array of 4 eleements and
# initilize array elements to 0 
# Element 0:0, 1:0, 2:0, 3:0 
rows = 4
c_array = [0 for _ in range(rows)]
print("Array Size is actual: " )

input("Press any Key to Continue...")
