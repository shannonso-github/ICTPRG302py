# you need to install pip install keyboard
# pip install keyboard
#
import keyboard

def wait_for_escape_key():
    print("Press the ESC key to exit.")

    while True:
        if keyboard.is_pressed("esc"):
            print("Exiting...")
            break

# Example usage:
wait_for_escape_key()
