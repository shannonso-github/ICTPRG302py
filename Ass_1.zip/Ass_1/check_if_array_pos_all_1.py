# file name: check_if_array_pos_all_1.py
c_array = [0][0]
columns = 3
rows = 7
def c_init():
    global c_array
    c_array = [[-1 for _ in range(columns)] for _ in range(rows)] # reinitialize array
    for i in range(len(c_array)):           # row
    #    print("i = " + str(i))
        for j in range(len(c_array[0])):    # column
            # if num % 2 != 0:
            if i % 2 == 0:
                c_array[i][j] = -2          # [row][colum]

positions_to_check = [
    [(1, 0), (1, 1), (1, 2)],
    [(3, 0), (3, 1), (3, 2)],
    [(5, 0), (5, 1), (5, 2)],
    [(1, 0), (3, 0), (5, 0)],
    [(1, 1), (3, 1), (5, 1)],
    [(1, 2), (3, 2), (5, 2)],
    [(1, 0), (3, 1), (5, 2)],
    [(1, 2), (3, 1), (5, 0)]
]

def chk_if_winner2(positions_to_check, value):
    n_cntr = 0
    winner_status = False
    while n_cntr < len(positions_to_check):
        positions = positions_to_check[n_cntr]
        row_values = [c_array[row][col] for row, col in positions]
        if all(val == value for val in row_values):
            print(f"Winner! {positions} are {value}.")
            winner_status = True
            #break
        else: 
            print(f"No winner. {positions} are {value}.")
        n_cntr += 1
    print("POSITIONS TO CHECK " + str(n_cntr))
    return winner_status


c_init()
c_array[1][0] = 1
c_array[1][1] = 1
c_array[1][2] = 1

player = 1

winner_status = chk_if_winner2(positions_to_check, player)
print("Press and key to continue...")
