# File Name: Basic_001.py Description: Simple 2D array
# column = 1,4,2
# row    = {row 1} , {row 2}
# a_array = { {1,4,2}, {3,6,8} }
#       Column 0 | Column 1 | Column 2
# row 0    1           4         2
# row 1    3           6         8
import os
def clear_screen(): os.system("cls")
clear_screen()
c_array = [[1,4,2], [3,6,8]]        # 3 columns, 2 rows excel A2 A=Column, 2 = row
print("c_array i: " + str(len(c_array)))
print("c_array j: " + str(len(c_array[0])))

for i in range(len(c_array)):           # row
    print("i = " + str(i))
    for j in range(len(c_array[0])):    # column
        print("Column " + str(c_array[i][j]))
        #print(c_array[i][j])
input("\nPress any key to continue... ")