# File Name: string_demo_001.py
# Given string
a_line = "9 12/3/2023 [1, 2, 3, 11, 14] [19]"

# Remove delimiters from the string
delimiters = [' ', ',', '[', ']']
for delimiter in delimiters:
    a_line = a_line.replace(delimiter, ' ')
# Split the modified string into words
words = a_line.split('/')
# Convert the list of words to a list of strings
temp = list(words)
# Print the result
print(temp)