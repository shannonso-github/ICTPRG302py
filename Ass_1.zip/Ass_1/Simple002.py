import os
def print_grid():
    rows = 0
    i = 0
    # print heading
    print("      0 | 1 | 2 | Column")
    #print grid
    print("0 | --- | --- | --- | Rows 1..6")
    i = i + 1
    print(str(i) + " |     |     |     |")
    i = i + 1
    print(str(i) + " | --- | --- | --- |")
    i += 1
    print(str(i) + " |     |     |     |")
    i += 1
    print(str(i) + " | --- | --- | --- |")
    i += 1
    print(str(i) + " |     |     |     |")
    i += 1
    print(str(i) + " | --- | --- | --- |")
    for i in range(rows):
        print(i)

def clear_screen():
    os.system("cls")

clear_screen()
print_grid()
print("Press any key to continue... ")
input()