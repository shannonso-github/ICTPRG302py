# File Name: String_2.4.py
temp = "   Hello World! "
first_name = "Joe"
last_name = "Smith"
# Method functions such as the following;
# Get the length of string 16 characters
length = len(temp)

# Convert all letters in string to upper case
upper_case = temp.upper()

# Concatenate two strings
full_name = first_name + " " + last_name

# Get the 15th character in the string, !
char_at_index_14 = temp[14]

# Find index position of the '!' which is at position 14
index_of_exclamation = temp.index("!")

# Extracts text from a string
substring = temp[3:8]  # Extracts "Hello"
input("Press any key to continue... ")