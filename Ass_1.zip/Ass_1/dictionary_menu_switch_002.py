import os # for clear screen
def clear_screen(): os.system("cls")
def read_data():    print("Menu option read_data()"), press_any_key()
def player_vs_computer(): print("Menu option player_vs_computer()"), press_any_key()
def case2(): print("menu option case2()"), press_any_key()
def case3(): print("menu option case3()"), press_any_key()
def case4_exit(): print("Exiting"), press_any_key()
def press_any_key(): a_key = input("Press any key to continue... ")
def display_menu():
    print("DOS-Style Menu:")
    print("1. Option 1")
    print("2. Option 2")
    print("3. Option 3")
    print("4. Exit")

switch_dict = {
            -2: read_data,
            1: player_vs_computer,
            2: case2,
            3: case3,
            4: case4_exit
        }

def tic_tac_toe_game():
    while True:
        clear_screen()
        # Display menu
        display_menu() 
        # Get user input
        try:
            user_choice = int(input("Enter choice (1-4): "))
        except ValueError:
            print("Invalid input. Please enter a number.")
            continue  # Restart the loop 
        
     # Dictionary to map cases to fun,       

        #Call the selected case fun or handle default case
        if user_choice in switch_dict:
            if switch_dict[user_choice]():
                break  # Exit the loop if case4 ret True
        else:
            print("Invalid choice.")
#main
tic_tac_toe_game()
