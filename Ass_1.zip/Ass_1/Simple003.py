# file name: Simple003.py
import os

def clear_screen():
    os.system("cls")

def press_anykey():
    input("Press any key to continue...")

def menu():
    print("Empty Project")

if __name__ == "__main__":
    clear_screen()
    menu()
    press_anykey()
