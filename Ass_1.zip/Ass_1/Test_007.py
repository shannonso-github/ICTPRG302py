def check_winner(board):
    # Check rows
    for row in board:
        if all(cell == -1 for cell in row):
            return True

    # Check columns
    for col in range(len(board[0])):
        if all(board[row][col] == -1 for row in range(len(board))):
            return True

    # Check diagonals
    if all(board[i][i] == -1 for i in range(min(len(board), len(board[0])))) or \
       all(board[i][len(board[0]) - i - 1] == -1 for i in range(min(len(board), len(board[0])))):
        return True

    return False

# Example usage with the provided data set
c_array = [
    [-2, -2, -2],
    [-1, -1, -1],
    [-2, -2, -2],
    [-1, -1, -1],
    [-2, -2, -2],
    [-1, -1, -1],
    [-2, -2, -2]
]

if check_winner(c_array):
    print("Player with -1 wins!")
else:
    print("No winner yet.")
