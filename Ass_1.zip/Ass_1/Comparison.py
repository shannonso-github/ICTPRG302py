# File name: Comparison.py
a, b, x = 2, 3, 0  # Initialize variables
print("a = 2, b = 3, x = 0")

if a == b:
    print(" a == b")
else:
    print("a does not equal b")

if a != b:
    print("a does not equal b")

if a > b:
    print("a is greater than b")
else:
    print("a is not greater than b")

if a < b:
    print("a is less than b")
else:
    print("a is not less than b")

input("Press Enter to continue...")
