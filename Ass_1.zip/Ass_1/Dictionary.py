# Activity 2.2.3 Datatypes – Dictionary.py
# Sample Dictionary
sample_dict = {
    'name': 'John',
    'age': 25,
    'city': 'New York'
}

# Accessing elements
print("Dictionary:")
print("Name:", sample_dict['name'])
print("Age:", sample_dict['age'])
print("City:", sample_dict['city'])
print("\n")