# File Name:   syntax_eg.py
# Description: This is a simple Python syntax example
x = 5 # a integer number
y = 10
sum_result = x + y
print("The sum of", x, "and", y, "is:", sum_result)