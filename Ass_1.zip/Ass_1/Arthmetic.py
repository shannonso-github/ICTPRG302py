# File Name: Arthmetic.py
a, b, x = 2, 3, 0  # initialize variables
print("a = 2, b = 3, x = 0")
x = a + b  # addition operator
print(" a + b = ", x)
x = a - b  # subtraction operator
print(" a - b = ", x)
x = a / b  # division operator (integer division in Python)
print(" a / b = ", x)
x = a % b  # modulus operator
print(" a % b = ", x)
a += 1
print(" a++ = ", a)
a -= 1
print(" a-- = ", a)
input("Press any key to continue...")