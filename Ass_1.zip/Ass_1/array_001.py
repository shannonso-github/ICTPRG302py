# File Name: array_001.py
c_array = [0][0]
rows = 7
columns = 3
def Initialize_array():
    global c_array
    c_array = [[-1 for _ in range(columns)] for _ in range(rows)] # reinitialize array

    for i in range(len(c_array)):           # row
    #    print("i = " + str(i))
        for j in range(len(c_array[0])):    # column
            # if num % 2 != 0:
            if i / 2 == 0:
                c_array[i][j] = -2          # [row][colum]

Initialize_array()
input("Press any key... ")