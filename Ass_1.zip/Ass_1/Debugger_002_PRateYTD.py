# Filename: PRateYTD.py
# Des: Year to date salary from pay rate
# Initialize variables
pay_rate = 0 
no_of_hours_worked = 0
weekly_pay = 0
weeks_in_year = 52  
# Dislay Heading
print("Calculate YTD Salary from pay rate")
print("============================================")
# Get user input
# Assuming user inputs a floating-point number
pay_rate = float(input("Enter your pay rate: "))
 # Assuming user inputs a floating-point number
no_of_hours_worked = float(input("Enter no of Hours worked: ")) 
# Calculate
weekly_pay = pay_rate * no_of_hours_worked
yearly_salary = weeks_in_year * weekly_pay
# Display YTF Salary
print("Your YTD Salary is:", round(yearly_salary, 2))
# Assuming input to stop program execution
input("Press any key to continue...")