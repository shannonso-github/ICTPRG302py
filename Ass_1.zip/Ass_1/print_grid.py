# File Name: print_grid.py
def print_grid(rows, columns):
    # Print column headers
    print("    ", end="")
    for col in range(columns):
        print(f"{col: >4}", end=" |")
    print("\n" + " " * 4 + "+---" * columns)

    # Print rows
    for row in range(rows):
        print(f"{row: <2} |", end="")
        for col in range(columns):
            print("    |", end="")
        print("\n" + " " * 4 + "+---" * columns)

# Set the number of rows and columns
num_rows = 9
num_columns = 3

# Print the grid
print_grid(num_rows, num_columns)
input("Press any key to continue...") # read input
