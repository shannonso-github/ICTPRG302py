# Number of rows and columns
rows = 4
columns = 3  # Assuming a 3x3 array for simplicity

# Create a 2D array initialized to -1
array_2d = [[-1] * columns for _ in range(rows)]

# Print the initial 2D array
print("Initial 2D array:")
for row in array_2d:
    print(row)

# Assign the value 9 to specific elements (e.g., first and last elements)
array_2d[0][0] = 9
array_2d[2][2] = 9

# Print the modified 2D array
print("\nModified 2D array:")
for row in array_2d:
    print(row)
