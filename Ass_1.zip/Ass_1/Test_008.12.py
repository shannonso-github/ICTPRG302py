# Provided data set c_array
# File name: Test_008.12.py
c_array = [
    [-2, -2, -2],
    [1, 1, 1],
    [-2, -2, -2],
    [-1, -1, -1],
    [-2, -2, -2],
    [3, 3, 3],
    [-2, -2, -2]
]

# Combine all sets of positions into one array
w_array = [
    [(1, 0), (1, 1), (1, 2)],
    [(3, 0), (3, 1), (3, 2)],
    [(5, 0), (5, 1), (5, 2)]
]

# Function to check if a set of positions contains all specified values
def check_for_winner(positions_to_check, value):
    row_values = [c_array[row][col] for row, col in positions_to_check]
    if all(val == value for val in row_values):
        print(f"Winner! All values in positions {positions_to_check} are {value}.")
    else:
        print(f"No winner. Not all values in positions {positions_to_check} are {value}.")

# Check for each set of positions in the combined array
for positions_to_check in w_array:
    check_for_winner(positions_to_check, 1)  # You can change the value to check for if needed
