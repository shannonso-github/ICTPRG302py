# Assuming c_array is a 2D array
# file name: Test_008.7.py
c_array = [
    [0, 0, 0],
    [0, 1, 0],
    [0, 0, 0],
    [0, 1, 0],
    [0, 0, 0],
    [0, 1, 0]
]

# List of positions to check
positions_to_check = [
    (1, 0), (1, 1), (1, 2),
    (3, 0), (3, 1), (3, 2),
    (5, 0), (5, 1), (5, 2)
]

# Check if the specified positions have the value 1 in c_array
for position in positions_to_check:
    row, col = position
    if c_array[row][col] == 1:
        print(f"Position {position} has the value 1")
    else:
        print(f"Position {position} does not have the value 1")
