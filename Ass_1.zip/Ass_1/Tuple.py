# Activity 2.2.4 Datatypes – Tuple.py

# Sample Tuple
sample_tuple = (1, 'apple', 3.14, True)

# Accessing elements
print("Tuple:")
print("First element:", sample_tuple[0])
print("Second element:", sample_tuple[1])
print("Third element:", sample_tuple[2])
print("Fourth element:", sample_tuple[3])
print("\n")