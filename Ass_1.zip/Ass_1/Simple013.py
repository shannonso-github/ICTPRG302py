# File name: Simple013.py
# Assigning values to variables
x = 5
y = "hello"
z = [1, 2, 3]

# Printing variable values
print(x)  # Output: 5
print(y)  # Output: hello
print(z)  # Output: [1, 2, 3]

# Variables can be reassigned with values of different types
x = "world"
print(x)  # Output: world

# Variable scope example
def my_function():
    local_var = "local variable"
    print(local_var)

my_function()  # Output: local variable
# print(local_var)  # This would result in an error because local_var is not accessible outside the function
