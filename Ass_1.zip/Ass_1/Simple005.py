# File Name: Simple005.py
print(__file__.name)
input("Press and key to continue..")