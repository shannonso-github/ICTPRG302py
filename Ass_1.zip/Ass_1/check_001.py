# File Name: check_001.py
# We want to create an array that stores
# information in the following format:
#   0   1   2
#0 -2  -2  -2
#1 -1  -1  -1
#2 -2  -2  -2
#3 -1  -1  -1
#4 -2  -2  -2
#5 -1  -1  -1
#6 -2  -2  -2
c_array = [0][0]
columns = 3
rows = 7
c_array = [[-1 for _ in range(columns)] for _ in range(rows)] # reinitialize array
for i in range(len(c_array)):           # row
#    print("i = " + str(i))
    for j in range(len(c_array[0])):    # column
        if i / 2 == 0:
            c_array[i][j] = -2          # [row][colum]
