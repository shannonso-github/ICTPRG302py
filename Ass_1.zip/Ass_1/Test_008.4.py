# File name: Test_008.4.py

# Provided data set c_array
c_array = [
    [-2, -2, -2],
    [1, 1, 1],
    [-2, -2, -2],
    [-1, -1, -1],
    [-2, -2, -2],
    [-1, -1, -1],
    [-2, -2, -2]
]

# Combined set of positions to check for each row
positions_to_check = [
    [(1, 0), (1, 1), (1, 2)],
    [(2, 0), (2, 1), (2, 2)]
]

# Function to check positions and find number 1 in c_array
def check_positions_and_find_number(row_positions):
    for position in row_positions:
        row, col = position
        if c_array[row][col] == 1:
            print(f"Position {position} has the value 1")
        else:
            print(f"Position {position} does not have the value 1")

# Check for each row's set of positions
for row_positions in positions_to_check:
    check_positions_and_find_number(row_positions)
