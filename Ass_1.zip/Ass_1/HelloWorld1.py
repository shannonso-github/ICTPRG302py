# File Name: HelloWorld.py
print("Hello World")
input("Press any key to continue...") # read input