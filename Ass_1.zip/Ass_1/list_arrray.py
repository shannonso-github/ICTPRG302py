# Activity 2.2.5 Datatypes - List/Array Filename: list_arrray.py

# Sample List/Array
sample_list = [10, 'orange', 2.71, False]

# Accessing elements
print("List/Array:")
print("First element:", sample_list[0])
print("Second element:", sample_list[1])
print("Third element:", sample_list[2])
print("Fourth element:", sample_list[3])
print("\n")