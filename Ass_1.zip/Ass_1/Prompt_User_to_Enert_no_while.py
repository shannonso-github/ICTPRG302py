# File Name: Prompt_User_to_Enert_no_2_while.py
def get_valid_number2(prompt_word, valid_numbers):
    while True:
        try:
            user_input = int(input("Enter " + prompt_word + " (" + ", ".join(map(str, valid_numbers)) + "): "))
            
            if user_input in valid_numbers:
                print("Row no is:", user_input)
                return user_input
            else:
                print("Error: Enter " + prompt_word + " from the valid options (" + ", ".join(map(str, valid_numbers)) + ").")
        except ValueError:
            print("Error: Enter a valid integer.")

prompt_word = "Row position no"
valid_numbers = [1, 3, 5]
row_pos = get_valid_number2(prompt_word, valid_numbers)