
# # Provided data set c_array
# Test_008.11.py
c_array = [
    [-2, -2, -2],
    [1, 1, 1],
    [-2, -2, -2],
    [-1, -1, -1],
    [-2, -2, -2],
    [3, 3, 3],
    [-2, -2, -2]
]

# Set of positions to check
positions_to_check_1 = [(1, 0), (1, 1), (1, 2)]
positions_to_check_2 = [(3, 0), (3, 1), (3, 2)]
positions_to_check_3 = [(5, 0), (5, 1), (5, 2)]

# Function to check if a set of positions contains all 1's
def check_for_winner(positions_to_check, n):
    row_values = [c_array[row][col] for row, col in positions_to_check]
    if all(value == n for value in row_values):
        print(f"Winner! All values in positions {positions_to_check} are 1.")
    else:
        print(f"No winner. Not all values in positions {positions_to_check} are 1.")

# Check for each set of positions
p=1
check_for_winner(positions_to_check_1, p)
p=3
check_for_winner(positions_to_check_2, p)
p=3
check_for_winner(positions_to_check_3, p)
