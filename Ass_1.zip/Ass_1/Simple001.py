import os
def print_grid():
    row = 0
    i = 0
    print("0 | --- | --- | --- |")
    i = i + 1
    print(str(i) + " | --- | --- | --- |")
    i += 1
    print(str(i) + " | --- | --- | --- |")

def clear_screen():
    os.system("cls")

clear_screen()
print_grid()
print("Press any key to continue... ")
input()