# File Name: Simple015.py
#
# Write some data to a text file in python
def write_to_file(data, filename):
    try:
        with open(filename, 'w') as file:
            file.write(data)
        print("Data has been written to", filename)
    except Exception as e:
        print("Error:", e)

# Example data
data = "This is some data that will be written to a file."

# Example filename
filename = "output.txt"

# Write data to file
write_to_file(data, filename)
