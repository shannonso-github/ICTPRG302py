# Provided data set c_array
# File name: Test_008.13.py
# this sample code checks for a data set that
# this sample of code looks at an array of data values and checks if the position cordinaords
# an array of tulpes.
c_array = [
    [-2, -2, -2],
    [-2, 1, -2],
    [-2, -2, -2],
    [-2, 1, -1],
    [-2, -2, -2],
    [3, 1, 3],
    [-2, -2, -2]
]

# Combine all sets of positions into one array
#positions_to_check = [
#    [(1, 0), (1, 1), (1, 2)],
#    [(3, 0), (3, 1), (3, 2)],
#    [(5, 0), (5, 1), (5, 2)]
#]

positions_to_check = [
    [(1, 0), (1, 1), (1, 2)],
    [(3, 0), (3, 1), (3, 2)],
    [(5, 0), (5, 1), (5, 2)],
    [(1, 0), (3, 0), (5, 0)],
    [(1, 1), (3, 1), (5, 1)],
    [(1, 2), (3, 2), (5, 2)],
    [(1, 0), (3, 1), (5, 2)],
    [(1, 2), (3, 1), (5, 0)]
]

# Function to check if a set of positions contains all specified values
def check_for_winner(positions, value):
    row_values = [c_array[row][col] for row, col in positions]
    if all(val == value for val in row_values):
        print(f"Winner! All values in positions {positions} are {value}.")
    else:
        print(f"No winner. Not all values in positions {positions} are {value}.")

# Check for each set of positions in the combined array
# positions = 0: (1, 0), 1: (1, 1), 2: (1, 2)
# 2D Array positions_to_check, with a tuble positions
for positions in positions_to_check:
    check_for_winner(positions, 1)  # You can change the value to check for if needed
