# file name: Simple007.py
import os
def clear_screen():
    os.system("cls")
def press_anykey():
    input("Press any key to continue...")
def menu():
    print("Empty Project")

rows = 3
c_array = [0 for _ in range(rows)]

#for ii in range(rows):
#        print("row " + str(ii))
#        for jj in range(columns):
#            print(c_array[ii][jj], end=" ")

def Simple006():
    for i in range(rows):
         c_array[i] = 0
         #print("row " + str(i) + str(c_array[i-1]))
    for ii in range(len(c_array)):
         print("row " + str(ii) + ": " + str(c_array[ii]))

if __name__ == "__main__":
    clear_screen()
    menu()
    Simple006()
    press_anykey()
