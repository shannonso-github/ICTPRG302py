import os;

def case1():
    print("Selected option: Player vs Computer")

def case2():
    print("Selected option: Player vs Player")

def case3():
    print("Selected option: View Data History")

def case4():
    print("Selected option: Exit")
    return True

def tic_tac_toe_game():
    while True:
        clear_screen()

        # Display menu
        print("Menu Options:")
        print("1. Player vs Computer")
        print("2. Player vs Player")
        print("3. View Data History")
        print("4. Exit")

        # Get user input
        user_choice = int(input("Enter your choice (1-4): "))

        # Dictionary to map cases to functions
        switch_dict = {
            1: case1,
            2: case2,
            3: case3,
            4: case4
        }

        # Call the selected case function or handle the default case
        switch_dict.get(user_choice, lambda: print("Invalid choice."))()

def clear_screen():
    os.system("cls")
def press_anykey():
    input("Press any key to continue...")

tic_tac_toe_game()
press_anykey()