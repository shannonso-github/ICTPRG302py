# File name: menu_switch.py
def option1():
    print("You selected Option 1.")
    # Add your Option 1 logic here

def option2():
    print("You selected Option 2.")
    # Add your Option 2 logic here

def option3():
    print("You selected Option 3.")
    # Add your Option 3 logic here

def exit_program():
    print("Exiting the program. Goodbye!")
    return False

# Dictionary mapping choices to functions
menu_options = {
    '1': option1,
    '2': option2,
    '3': option3,
    '4': exit_program
}

def display_menu():
    print("DOS-Style Menu:")
    print("1. Option 1")
    print("2. Option 2")
    print("3. Option 3")
    print("4. Exit")

def test():
    while True:
        choice = input("Enter the number of your choice: ")
        
        if choice in menu_options:
            # Retrieve and call the function corresponding to the choice
            selected_option = menu_options[choice]
            selected_option()
            if selected_option == "4":            
                break
        else:
            print("Invalid choice. Please enter a valid option.")

test()