#file name: string_exp_007.py
import re
a_line = "9 12/3/2023 [1,2,3,11,14] [19]" 
# Remove all white spaces
a_line_no_spaces = re.sub(r'\s+', '', a_line)
# Extract parts using regular expressions
pattern = re.compile(r'(\d+)(\d{2}/\d{2}/\d{4})(\[[^\]]+\])(\[[^\]]+\])')
match = pattern.search(a_line_no_spaces)
if match:
    first_number = match.group(1)
    date = match.group(2)
    list1 = match.group(3)
    list2 = match.group(4)    
    print("First number:", first_number)
    print("Date:", date)
    print("List 1:", list1)
    print("List 2:", list2)
else:
    print("Pattern not found.")