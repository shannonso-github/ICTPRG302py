#file name: extract_u_re.py
import re

# Given string
a_line = "9 12/3/2023 [1, 2, 3, 11, 14] [19]"

# Define the regular expression pattern
pattern = r'(\d+)\s+(\d+/\d+/\d+)\s+(\[[^\]]+\])\s+(\[[^\]]+\])'

# Use the findall() function to extract matching parts
matches = re.findall(pattern, a_line)

# Extract the parts
if matches:
    for match in matches:
        part1, part2, part3, part4 = match
        print("Part 1:", part1)
        print("Part 2:", part2)
        print("Part 3:", part3)
        print("Part 4:", part4)
else:
    print("No matches found.")