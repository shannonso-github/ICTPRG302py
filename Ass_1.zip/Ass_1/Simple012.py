# File name: Simple012.py, Web Example, 
# This File uses index.html file.
# also need to install flash
# 
#   pip install Flask
#
from flask import Flask, render_template

app = Flask(__name__)

# Define a route for the homepage
@app.route('/')
def index():
    # Render the HTML template named 'index.html'
    return "Hello World"
    #return render_template('index.html')

if __name__ == '__main__':
    # Run the Flask application  
    app.run(debug=True)
    #app.run(host="127.0.0.1", port=8080, debug=True)
