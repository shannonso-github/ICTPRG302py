import pygame

WITDTH, HEIGHT = 1200, 800
fps = 30

pygame.init()
sc = pygame.display.set_mode((WITDTH, HEIGHT)) # screen

clock = pygame.time.Clock()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()
    #pygame.display.flip()
    #clock.tick()(fps)