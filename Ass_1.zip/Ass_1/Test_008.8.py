# Assuming c_array is a 2D array
# File name: Test_008.8.py
c_array = [
    [0, 0, 0],
    [1, 1, 1],
    [0, 0, 0],
    [2, 1, 0],
    [0, 0, 0],
    [0, 2, 0]
]

# List of positions to check
positions_to_check = [
    (1, 0), (1, 1), (1, 2),
    (3, 0), (3, 1), (3, 2),
    (5, 0), (5, 1), (5, 2)
]

# Check if the specified positions have the value 1 in c_array
for idx, (i, j) in enumerate(positions_to_check, start=1):
    if c_array[i][j] == 1:
        print(f"Tuple pair {idx}: Position ({i}, {j}) has the value 1")
    else:
        print(f"Tuple pair {idx}: Position ({i}, {j}) does not have the value 1")
