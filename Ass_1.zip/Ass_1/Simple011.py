# file name: Simple011.py - GUI Uing thinker
import tkinter as tk

def update_label():
    label.config(text="Button Clicked!")

# Create the main application window
root = tk.Tk()
root.title("Simple GUI App")

# Create a label widget
label = tk.Label(root, text="Welcome to the GUI App")
label.pack(pady=10)

# Create a button widget
button = tk.Button(root, text="Click Me", command=update_label)
button.pack()

# Run the main event loop
root.mainloop()
