# Filename: Debugger_001.py
# YTDPRate.py
# Initialize variables
yearly_salary = 0
hours_worked_per_week = 0
# Display heading
print("Caculate pay rate from Yearly Salary ")
print("============================================")
# Prompt user for input
yearly_salary = round(float(input("Enter yearly salary: ")),2)
hours_worked_per_week = round(float(input("Enter number of hours worked per week: ")),2)
# Calculate weekly pay
weekly_pay = round((yearly_salary / 52), 2)
# Calculate pay rate
pay_rate = round((weekly_pay / hours_worked_per_week),2)
# Display pay rate
print("Pay rate:", pay_rate)
input("Press any key to continue...")
