#File Name: py_switch_eg.py
import os # for clear screen
def clear_screen(): os.system("cls")
def press_anykey(): 
    a_key = input("Press any key to continue... ")
def read_data():  
    print("Menu option read_data()"), 
    press_anykey()
def player_vs_computer(): 
    print("player_vs_computer()")
    press_anykey()
def case2():    
    print("menu option case2()"), 
    press_anykey()
def case3():    
    print("menu option case3()")
    press_anykey()
def case4_exit(): return True
def display_menu():
    print("1. player_vs_computer")
    print("2. Option 2")
    print("3. Option 3")
    print("-1 Read Data")
    print("4. Exit")

def tic_tac_toe_game():
    while True:
        clear_screen()
        # Display menu
        display_menu() 
        # Get user input
        try:
            user_choice = int(input("Enter your choice (1-4): "))
        except ValueError:
            print("Invalid input. Please enter a number.")
            press_anykey()
            continue  # Restart the loop if the input is not a number

        # Dictionary to map cases to functions, -3: create_game_grid_data,
        switch_dict = {
            -1: read_data,
            1: player_vs_computer,
            2: case2,
            3: case3,
            4: case4_exit
        }

        # Call the selected case function or handle the default case
        if user_choice in switch_dict:
            if switch_dict[user_choice]():
                break  # Exit the loop if case4 returns True
        else:
            print("Invalid choice.")
            press_anykey()
#main
tic_tac_toe_game()