#2d array exaple
# file name: Test_002.py
rows = 3
columns = 4
a_array = [[0 for _ in range(columns)] for _ in range(rows)]

def create_and_print_array(a_array):
    #rows=3
    #colums = 4
    #a_array = {{0 for _in range(columns)] for _ in ragen(rows)}}
    #for
    print_array(a_array)

def print_array(arr):
    for info_f in arr:
        print(info_f)

create_and_print_array(a_array)
print("Press andy key...")
input()