import os

def clear_screen():
    os.system("cls")

def press_anykey():
    input("Press Enter to continue...")

def player_vs_computer():
    print("1. Player vs Computer")

def case2():
    print("2. Player vs Player")

def case3():
    print("3. View Data History")

def case4_exit():
    print("Selected option: Exit")
    return True  # Indicate to exit the loop

def tic_tac_toe_game():
    while True:
        clear_screen()

        # Display menu
        print("Menu Options:")
        print("1. Player vs Computer")
        print("2. Player vs Player")
        print("3. View Data History")
        print("4. Exit")

        # Get user input
        try:
            user_choice = int(input("Enter your choice (1-4): "))
        except ValueError:
            print("Invalid input. Please enter a number.")
            press_anykey()
            continue  # Restart the loop if the input is not a number

        # Dictionary to map cases to functions
        switch_dict = {
            1: player_vs_computer,
            2: case2,
            3: case3,
            4: case4_exit
        }

        # Call the selected case function or handle the default case
        if user_choice in switch_dict:
            if switch_dict[user_choice]():
                break  # Exit the loop if case4 returns True
        else:
            print("Invalid choice.")

        press_anykey()



tic_tac_toe_game()
