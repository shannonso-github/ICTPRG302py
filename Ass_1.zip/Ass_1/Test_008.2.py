# 1D Array (List)
arr_1d = [1, 2, 3, 4, 5]

# Accessing elements
element_at_index_2 = arr_1d[2]  # Value: 3
print()
print("arr_1d = [1, 2, 3, 4, 5]")
print("1 d element_at_index_2 = arr_1d[2] is: " + str(arr_1d[2]))
print()
# 2D Array (List of Lists)
arr_2d = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

print("arr_2d = [1, 2, 3],")
print("         [4, 5, 6],")
print("         [7, 8, 9]")
print()
# Accessing elements
element_at_row_1_col_2 = arr_2d[1][2]  # Value: 6

print("2d element_at_row_1_col_2 = arr_2d[1][2]: " + str(arr_2d[1][2]))

# Example 2 with i and j

# Creating a 2D array
arr_2d = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

# Accessing elements using i and j
for i in range(len(arr_2d)):
    for j in range(len(arr_2d[0])):
        print(f"Element at row {i}, column {j}: {arr_2d[i][j]}")

# Example 3 2d Array with i and j
# Given 2D array
arr_2d = [
    [1, 2, 3],
    [4, 1, 6],
    [7, 8, 1]
]

# Positions to check,
# l want these elements from the array
# paring of elements, and an arrray with 3 fileds or columns
#positions_to_check = [(0, 0), (0, 1), (0, 2)] # straight - [(0, 1), (1, 1), (2, 1)] # row 1
positions_to_check = [(0, 0), (1, 1), (2, 2)] # dig \ # [(0, 1), (1, 1), (2, 1)] # row 1

#positions_to_check = [
# (0, 1),
# (1, 1),
# (2, 1)

# Find numbers with all 1's in the specified positions
result_numbers = []
for position in positions_to_check:
    i, j = position
    if arr_2d[i][j] == 1:
        result_numbers.append(arr_2d[i][j])

# Display the result
if result_numbers:
    print(f"Numbers with all 1's in specified positions: {result_numbers}")
else:
    print("No numbers with all 1's in specified positions.")
