# file name: Simple008.py
# ERROR - CODE NOT AN EXAMPLE SCRAP SEE FILE
import os
def clear_screen():
    os.system("cls")
def press_anykey():
    input("Press any key to continue...")
def menu():
    print("Empty Project")

rows = 3
columns = 8
c_array = [[0 for _ in range(columns)] for _ in range(rows)]

# column = 1,4,2
# row    = {row 1} , {row 2}
# a_array = { {1,4,2}, {3,6,8} }
#       Column 0 | Column 1 | Column 2
# row 0    1           4         2
# row 1    3           6         8

# for ii in range(rows):
#        print("row " + str(ii))
#        for jj in range(columns):
#            print(c_array[ii][jj], end=" ")


def Simple008():
    for j in range(columns):
        for i in range(rows):
            c_array[i][j] = 0
            #print("row " + str(i) + str(c_array[i-1]))
    for j in range(len(c_array[0])):
        for i in range(rows):
            if i == 0:
                print("     " + str(j) + "   " + "|  " + str(j+1) + " |  " + str(j+2))
            if i > 0:
                print(str(i) + "|  " + str(c_array[i][j]) + "|  " )

if __name__ == "__main__":
    clear_screen()
    menu()
    Simple008()
    press_anykey()
